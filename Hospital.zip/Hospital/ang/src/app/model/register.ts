export class Register {
    Id: number;
    firstName: string;
    middleName: string;
    lastName: string;
    gender: string;
    dob:any;
    email: any;
    mobile: number;
    speciality: any;
    doctorName: string;
    timing:any
}