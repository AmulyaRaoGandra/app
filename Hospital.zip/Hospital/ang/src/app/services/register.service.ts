import { Injectable } from '@angular/core';
import {Register} from '../model/Register';
import {Observable, observable} from 'rxjs'
import {HttpClient,HttpHeaders} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  httpOptions={headers: new HttpHeaders({'Content-Type':'application/json'})
};

 myurl=' http://localhost:3400';
  constructor(private http:HttpClient) {}
  saveAddfrm(reg: Register): Observable<any>{
    alert(JSON.stringify(reg));
  return this.http.post( this.myurl+'/insert', JSON.stringify(reg), this.httpOptions)
  }
  // getAllEmployeeDetails():Observable<any> {
  //   return this.http.get(this.myurl+'/get', { responseType: 'json' })
  // }

  getAppointements():Observable<any>{
    return this.http.get(this.myurl+'/get',{responseType:'json'})
  }
 

}





