import { Component, OnInit } from '@angular/core';
import { Register } from '../model/register';
import { RegisterService } from '../services/register.service';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
 reg:Register
 regs:any;
  constructor(private registerservice:RegisterService) {
    this.reg=new Register();
   }

  

  ngOnInit() {
  this.registerservice.getAppointements().subscribe((data)=>{
    this.regs=data;
    console.log(this.regs)
  })
  }

}
