import { Component, OnInit, ViewChild } from '@angular/core';
import { Register } from '../model/register';
import { RegisterService } from '../services/register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  reg: Register
  constructor(private registerss: RegisterService, private router: Router) {
    this.reg = new Register();
  }

  @ViewChild('frm') form: any


  addForm(frm) {
    if (frm.valid) {
      this.registerss.saveAddfrm(this.reg).subscribe((data) => {
        // this.router.navigate(['users'])
      })
    }

  }

  submitForm(frm) {
    let frmValid: boolean
    frmValid = frm.valid
    if (frmValid == true) {
      alert('Appointed successfully')
      this.router.navigate(['users'])
    }
    else
      alert('Invalid details')
    }

  ngOnInit() {
  }

}
