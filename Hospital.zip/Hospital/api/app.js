var express = require('express');
var path = require('path');
var fs = require('fs')
var promise = require('bluebird');
var options = { promiseLib: promise };
var pgp = require('pg-promise')(options);

var bodyparser = require('body-parser');

var app = new express();
var cs = "postgres://postgres:root1@localhost:5432/hospital";
var db = pgp(cs);

app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

app.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});


app.get('/get', (req, res, next) => {
    db.any('select * from appointment order by  dob asc').then((data) => {
        res.send(data)
    })
})

app.post('/insert', (req, res, next) => {
    var FirstName = req.body.firstName;
    var MiddleName = req.body.middleName;
    var LastName = req.body.lastName;
    var Gender = req.body.gender;
    var DOB = req.body.dob;
    var Email = req.body.email;
    var Mobile = req.body.mobile;
    var Speciality = req.body.speciality;
    var DoctorName = req.body.doctorName;
    var Timing = req.body.timing
    console.log(req.body);
    db.none('select * from fn_addappoinments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)', [FirstName, MiddleName, LastName, Gender, DOB, Email, Mobile, Speciality, DoctorName, Timing]).then(() => {
        console.log('Record Inserted...')
        res.status(200).send({ message: 'Inserted Success...' });
    })
})
// app.get('/get', (req, res, next) => {

//     db.any('select * from fn_getall()').then((data) => {
//         res.status(200).send(data);
//     })
// })



app.listen(3400, (err) => {
    if (err) {
        console.log('Server cannot Start....error....');
    }
    else {
        console.log('server Started at : htttp://localhost:3400')
    }
})
